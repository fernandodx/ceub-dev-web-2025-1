
# Projeto Final - T-Sushi 

Este é o projeto final da disciplina de Desenvolvimento Web, baseado no sistema original `tburguer`, mas totalmente adaptado para o tema **sushi**.

##  Desenvolvido por
**Kayo dos Santos Muller**

---

## ✅ Funcionalidades implementadas

- ✅ Componente reutilizável de mensagens (alerta e sucesso)
- ✅ Validação de campos obrigatórios no formulário de pedidos
- ✅ Mensagens de sucesso ao criar, alterar ou excluir um pedido
- ✅ Tabela escondida quando não há pedidos cadastrados
- ✅ Troca completa de tema para **sushi**
  - Textos
  - Imagens
  - Dados do `db.json`
  - Estilo visual

---

## Prévia visual

Imagens de sushi são exibidas nos cards da interface. Você pode visualizar três tipos diferentes já incluídos na pasta `assets/`.

---

## Como rodar o projeto

### 1. Instale as dependências
```bash
npm install
```

### 2. Inicie o JSON Server
```bash
npx json-server --watch db.json --port 3000
```

### 3. Rode o projeto no navegador
```bash
npm run dev
```

Acesse: [http://localhost:5173](http://localhost:5173)

---

## Estrutura esperada para entrega

O projeto deve estar localizado dentro do repositório original em:

```
Professor/Kayo dos Santos Muller/projeto_final/
```

---

## Data de entrega

01 de Julho de 2025

---

## 📝 Observações

EU TENTEI!!!!! O **SS** de acordo com o enunciado. Boa correção, professor! 
