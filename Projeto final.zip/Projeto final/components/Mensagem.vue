<template>
  <div :class="['mensagem', tipo]">
    {{ texto }}
  </div>
</template>
<script>
export default {
  props: ['tipo', 'texto']
}
</script>
<style>
.mensagem {
  padding: 10px;
  border-radius: 5px;
  margin: 10px 0;
}
.sucesso {
  background-color: #d4edda;
  color: #155724;
}
.alerta {
  background-color: #f8d7da;
  color: #721c24;
}
</style>