
<template>
  <div>
    <h1>T-Sushi</h1>
    <footer>
  <p>Desenvolvido por Kayo dos Santos Muller</p>
</footer>
    <Mensagem :tipo="mensagem.tipo" :texto="mensagem.texto" v-show="mensagem.texto" />
    <div class="cards">
      <div v-for="img in imagens" :key="img" class="card">
        <img :src="img" alt="Sushi" />
        <p>Escolha seu sushi</p>
      </div>
    </div>
  </div>
</template>

<script>
import Mensagem from './components/Mensagem.vue'

export default {
  components: { Mensagem },
  data() {
    return {
      mensagem: { tipo: '', texto: '' },
      imagens: [
        './assets/sushi1.jpg',
        './assets/sushi2.jpg',
        './assets/sushi3.jpg'
      ]
    }
  }
}
</script>

<style>
.cards {
  display: flex;
  gap: 20px;
}
.card {
  border: 1px solid #ccc;
  padding: 10px;
  width: 200px;
}
.card img {
  width: 100%;
  height: auto;
  border-radius: 10px;
}
</style>
